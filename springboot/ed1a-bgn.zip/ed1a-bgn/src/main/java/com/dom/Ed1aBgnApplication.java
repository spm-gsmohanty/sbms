package com.dom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ed1aBgnApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ed1aBgnApplication.class, args);
	}

}
