package com.dom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ed1aBgnApplicationTests {

	@Test
	void contextLoads() {
	}

}
