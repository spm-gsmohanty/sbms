package com.domain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ld5aSbtConsoleAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ld5aSbtConsoleAppApplication.class, args);
	}

}
